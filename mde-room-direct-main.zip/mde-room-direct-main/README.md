# MDe Guest House Direct

Build a clean, high-converting, mobile-first website and direct-booking web application for "MDe Guest House" in Mthatha using React, Tailwind CSS, shadcn/ui components, and Lucide icons.

1. Business Profile & Contact Details

-Business Name: MDe Guest House

-Location: Joe Slovo, 4-Way Stop, Mthatha Dam Road, Mthatha, Eastern Cape

-Phone / Direct Call: 078 326 8757 (`tel:0783268757`)

-WhatsApp Direct Line: +27 78 326 8757 (`https://wa.me/27783268757`)

-Email: mdguesthouse8@gmail.com (`mailto:mdguesthouse8@gmail.com`)



2. Design & Copy Guidelines

-Visual Style: Warm, hospitable, clean, and mobile-optimized. Soft warm stone/off-white background (`#FAF9F6`), deep slate/charcoal text (`#1E293B`), warm amber accents (`#D97706`), crisp white cards with subtle borders (`border-stone-200`).

-Copywriting: Direct, clear, host-written, and practical. Avoid generic AI marketing buzzwords (do not use "oasis", "paradise", "unmatched luxury", "unleash"). Focus on cleanliness, privacy, secure parking, and affordability.



3. Inventory, Pricing & Key Property Features

-Inventory: 7 identical private bedrooms (Numbered Room 1 to Room 7).

-In-Room Amenities (All Rooms): Double Bed, Private En-Suite Bathroom (Shower & Toilet), TV, Bar Fridge, Microwave, Electric Kettle (Tea/Coffee), Cooling Fan, Wardrobe, Table, Chairs, Iron & Ironing Board.

-Key Property Features:

  -Secure Private Parking: Dedicated, safe on-site parking for guests with vehicles.

  -Community & Guest Laundry Service: Professional wash, dry, and iron services.

-Pricing Schedule:

  -Overnight Stay: R400 / night

  -Short Stay (1 Hour): R100

  -Short Stay (2 Hours): R150





4. Website Pages & Sections



1. Header & Quick Actions:

   - Property Name: MDe Guest House

   - Direct Action Buttons:

     - "Call Us" button triggering `tel:0783268757`

     - "WhatsApp" button opening `https://wa.me/27783268757`

   - Navigation links: Rooms & Rates, Private Parking & Amenities, Laundry, Location, Contact, Admin.



2. Hero Section:

   - Headline: "Affordable, Private & Secure Accommodation in Mthatha"

   - Subtitle: "Located at the Joe Slovo 4-Way Stop on Mthatha Dam Road. Private en-suite rooms, secure on-site parking, and 24/7 rest stops."

   - Direct CTA buttons:

     -[Book via WhatsApp] (Primary amber button)

     -[Call 078 326 8757] (Secondary outline button)

   - Property feature badges: `Overnight: R400` | `1 Hr: R100` | `2 Hrs: R150` | `✓ Secure Private Parking`.



3. Key Highlights & Amenities Bar:

   - Visual icon strip highlighting top reasons to stay:

     - Private On-Site Parking: Safe, gated space for your car.

     -Private En-Suite Bathrooms: Full privacy in every room.

     -In-Room Kitchenette Essentials: Fridge, microwave, and kettle.

     -Laundry Service On-Site: Wash and iron available daily.



4. Interactive Rate Calculator & Direct Booking:

   - Toggle tabs: Overnight Stay vs. Short Stay (Hourly).

   - Dynamic quote generation with an instant "Confirm on WhatsApp" button that auto-formats a message to `+27 78 326 8757`:

     -Overnight format: `"Hi MDe Guest House, I would like to book a room for [Nights] night(s) checking in on [Date]. I will need private parking: [Yes/No]. Total quote: R[Amount]."`

     - Short stay format: `"Hi MDe Guest House, I would like to book a room for a [1 Hour / 2 Hours] stay today at [Arrival Time]."`



5. Room Directory (7 Rooms):

   - Clean photo cards showcasing the bedrooms.

   - Clear icon list for all amenities: Double Bed, En-suite Shower, TV, Bar Fridge, Microwave, Kettle, Fan, Wardrobe, Ironing Board, Secure Parking Included.

   - Status tag per room (`Available` / `Occupied`).



6. Laundry Services Section:

   - Headline: "Professional Laundry & Ironing Service"

   - Description: "Open to both in-house guests and surrounding Mthatha & Joe Slovo residents."

   - Service cards: Wash & Dry, Ironing & Folding, Fast Turnaround Drop-off.

   - Direct "Inquire About Laundry" button pre-filling a WhatsApp message or email to `mdguesthouse8@gmail.com`.



7. Location, Parking & Directions:

   - Address: Joe Slovo, 4-Way Stop, Mthatha Dam Road, Mthatha.

   - Note on access: Easy roadside access with enclosed, safe private parking inside the premises.

   - Embedded Google Maps placeholder and direct "Get Directions" button.



8. Contact & Footer:

   - Full details: Phone `078 326 8757`, Email `mdguesthouse8@gmail.com`, Address.

   - Quick message form (saves to Supabase and falls back to mailto).

   - Persistent floating WhatsApp button with an online status indicator linking to `https://wa.me/27783268757`.



9. Admin Dashboard (`/admin`):

   - Visual room grid (Rooms 1 through 7) with 1-click status toggles (`Available`, `Occupied`, `Cleaning`).

   - Reservations tracker for overnight and hourly stays (including parking notes).

   - Laundry service order ledger for guest and community drop-offs.



5. Supabase Database Schema

- `rooms`: id (1-7), room_number (integer), title (string), status (text: 'available', 'occupied', 'cleaning'), has_parking (boolean, default true), is_active (boolean).

- `bookings`: id, room_id, guest_name, guest_phone, stay_type (text: 'overnight', '1_hour', '2_hours'), needs_parking (boolean), check_in (timestamp), check_out (timestamp), total_amount (numeric), payment_status (text), created_at (timestamp).

- `laundry_orders`: id, customer_name, phone_number, customer_type (text: 'guest', 'local_resident'), service_type (text), notes (text), status (text: 'received', 'in_progress', 'ready', 'collected'), created_at (timestamp).

- `messages`: id, name, phone, email, message, created_at (timestamp).

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/6e85135d-9e62-4d93-a0d0-33064d2cb7a8).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
