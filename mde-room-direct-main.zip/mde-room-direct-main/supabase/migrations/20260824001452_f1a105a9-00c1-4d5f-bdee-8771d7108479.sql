CREATE TABLE public.site_settings (
  id boolean NOT NULL PRIMARY KEY DEFAULT true CHECK (id),
  name text NOT NULL DEFAULT 'MDe Guest House',
  address text NOT NULL DEFAULT '',
  short_address text NOT NULL DEFAULT '',
  phone_display text NOT NULL DEFAULT '',
  whatsapp_number text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  maps_query text NOT NULL DEFAULT '',
  about text NOT NULL DEFAULT '',
  rate_overnight numeric NOT NULL DEFAULT 400,
  rate_one_hour numeric NOT NULL DEFAULT 100,
  rate_two_hours numeric NOT NULL DEFAULT 150,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.site_settings TO anon;
GRANT SELECT, INSERT, UPDATE ON public.site_settings TO authenticated;
GRANT ALL ON public.site_settings TO service_role;

ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view site settings" ON public.site_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Staff can insert site settings" ON public.site_settings FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Staff can update site settings" ON public.site_settings FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.contacts (
  id uuid NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL DEFAULT 'Reception',
  person_name text,
  role text,
  phone text,
  whatsapp_number text,
  email text,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.contacts TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.contacts TO authenticated;
GRANT ALL ON public.contacts TO service_role;

ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active contacts" ON public.contacts FOR SELECT TO anon USING (is_active);
CREATE POLICY "Staff can view all contacts" ON public.contacts FOR SELECT TO authenticated USING (true);
CREATE POLICY "Staff can insert contacts" ON public.contacts FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Staff can update contacts" ON public.contacts FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Staff can delete contacts" ON public.contacts FOR DELETE TO authenticated USING (true);

CREATE OR REPLACE FUNCTION public.update_updated_at_column() RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_site_settings_updated_at BEFORE UPDATE ON public.site_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_contacts_updated_at BEFORE UPDATE ON public.contacts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.site_settings (id, name, address, short_address, phone_display, whatsapp_number, email, maps_query, about)
VALUES (
  true,
  'MDe Guest House',
  'Joe Slovo, 4-Way Stop, Mthatha Dam Road, Mthatha, Eastern Cape',
  'Joe Slovo, 4-Way Stop, Mthatha Dam Road, Mthatha',
  '078 326 8757',
  '27783268757',
  'mdguesthouse8@gmail.com',
  'Mthatha Dam Road, Joe Slovo 4-Way Stop, Mthatha, Eastern Cape',
  'Seven private rooms with en-suite bathrooms and secure parking, a short drive from central Mthatha.'
);

INSERT INTO public.contacts (label, person_name, role, phone, whatsapp_number, email, sort_order)
VALUES
  ('Reception', NULL, 'Bookings and enquiries', '078 326 8757', '27783268757', 'mdguesthouse8@gmail.com', 1);