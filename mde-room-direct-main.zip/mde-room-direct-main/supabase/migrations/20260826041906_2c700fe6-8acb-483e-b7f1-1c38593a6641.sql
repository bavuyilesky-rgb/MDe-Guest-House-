ALTER TABLE public.site_settings ALTER COLUMN map_lat SET DEFAULT 0, ALTER COLUMN map_lng SET DEFAULT 0;
UPDATE public.site_settings SET map_lat = 0, map_lng = 0;