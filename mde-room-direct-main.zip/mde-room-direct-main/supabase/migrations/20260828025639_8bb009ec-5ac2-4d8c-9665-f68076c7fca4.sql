ALTER TABLE public.site_settings ADD COLUMN IF NOT EXISTS facebook_url text;
ALTER TABLE public.site_settings ADD COLUMN IF NOT EXISTS instagram_url text;

UPDATE public.site_settings
SET facebook_url = COALESCE(facebook_url, 'https://facebook.com/mdeguesthouse'),
    instagram_url = COALESCE(instagram_url, 'https://instagram.com/mdeguesthouse')
WHERE id = true;