CREATE TABLE public.rooms (
  id integer PRIMARY KEY,
  room_number integer NOT NULL UNIQUE,
  title text NOT NULL,
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available','occupied','cleaning')),
  has_parking boolean NOT NULL DEFAULT true,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.rooms TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.rooms TO authenticated;
GRANT ALL ON public.rooms TO service_role;
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view rooms" ON public.rooms FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Staff can update rooms" ON public.rooms FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Staff can insert rooms" ON public.rooms FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Staff can delete rooms" ON public.rooms FOR DELETE TO authenticated USING (true);

INSERT INTO public.rooms (id, room_number, title) VALUES
 (1,1,'Room 1'),(2,2,'Room 2'),(3,3,'Room 3'),(4,4,'Room 4'),(5,5,'Room 5'),(6,6,'Room 6'),(7,7,'Room 7');

CREATE TABLE public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id integer REFERENCES public.rooms(id) ON DELETE SET NULL,
  guest_name text NOT NULL,
  guest_phone text NOT NULL,
  stay_type text NOT NULL CHECK (stay_type IN ('overnight','1_hour','2_hours')),
  needs_parking boolean NOT NULL DEFAULT false,
  check_in timestamptz,
  check_out timestamptz,
  total_amount numeric NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending','paid','cancelled')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.bookings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookings TO authenticated;
GRANT ALL ON public.bookings TO service_role;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can request a booking" ON public.bookings FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Staff can view bookings" ON public.bookings FOR SELECT TO authenticated USING (true);
CREATE POLICY "Staff can update bookings" ON public.bookings FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Staff can delete bookings" ON public.bookings FOR DELETE TO authenticated USING (true);

CREATE TABLE public.laundry_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  phone_number text NOT NULL,
  customer_type text NOT NULL DEFAULT 'local_resident' CHECK (customer_type IN ('guest','local_resident')),
  service_type text NOT NULL,
  notes text,
  status text NOT NULL DEFAULT 'received' CHECK (status IN ('received','in_progress','ready','collected')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.laundry_orders TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.laundry_orders TO authenticated;
GRANT ALL ON public.laundry_orders TO service_role;
ALTER TABLE public.laundry_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can submit laundry order" ON public.laundry_orders FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Staff can view laundry orders" ON public.laundry_orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "Staff can update laundry orders" ON public.laundry_orders FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Staff can delete laundry orders" ON public.laundry_orders FOR DELETE TO authenticated USING (true);

CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text,
  email text,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.messages TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can send a message" ON public.messages FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Staff can view messages" ON public.messages FOR SELECT TO authenticated USING (true);
CREATE POLICY "Staff can delete messages" ON public.messages FOR DELETE TO authenticated USING (true);