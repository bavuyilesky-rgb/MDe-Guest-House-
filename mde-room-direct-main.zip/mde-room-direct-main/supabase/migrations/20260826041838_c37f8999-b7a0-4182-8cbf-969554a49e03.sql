ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS map_lat numeric NOT NULL DEFAULT -31.60250,
  ADD COLUMN IF NOT EXISTS map_lng numeric NOT NULL DEFAULT 28.79190,
  ADD COLUMN IF NOT EXISTS hero_title text NOT NULL DEFAULT 'Affordable, Private & Secure Accommodation in Mthatha',
  ADD COLUMN IF NOT EXISTS hero_subtitle text NOT NULL DEFAULT 'Located at the Joe Slovo 4-Way Stop on Mthatha Dam Road. Private en-suite rooms, secure on-site parking, and 24/7 rest stops.',
  ADD COLUMN IF NOT EXISTS hero_image_url text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS room_image_url text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS laundry_image_url text NOT NULL DEFAULT '';