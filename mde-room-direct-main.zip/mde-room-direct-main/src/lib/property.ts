export const PROPERTY = {
  name: "MDe Guest House",
  address: "Joe Slovo, 4-Way Stop, Mthatha Dam Road, Mthatha, Eastern Cape",
  shortAddress: "Joe Slovo, 4-Way Stop, Mthatha Dam Road, Mthatha",
  phoneDisplay: "078 326 8757",
  phoneHref: "tel:0783268757",
  whatsappNumber: "27783268757",
  email: "mdguesthouse8@gmail.com",
  emailHref: "mailto:mdguesthouse8@gmail.com",
  mapsQuery: "Mthatha Dam Road, Joe Slovo 4-Way Stop, Mthatha, Eastern Cape",
} as const;

export const RATES = {
  overnight: 400,
  oneHour: 100,
  twoHours: 150,
} as const;

export const ROOM_COUNT = 7;

export const ROOM_AMENITIES = [
  "Double Bed",
  "En-suite Shower & Toilet",
  "TV",
  "Bar Fridge",
  "Microwave",
  "Electric Kettle",
  "Cooling Fan",
  "Wardrobe",
  "Table & Chairs",
  "Iron & Ironing Board",
  "Secure Parking Included",
] as const;

export function whatsappLink(message: string) {
  return `https://wa.me/${PROPERTY.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export const WHATSAPP_PLAIN = `https://wa.me/${PROPERTY.whatsappNumber}`;

export const directionsLink = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
  PROPERTY.mapsQuery,
)}`;

export const mapEmbedSrc = `https://www.google.com/maps?q=${encodeURIComponent(
  PROPERTY.mapsQuery,
)}&output=embed`;

export function randsFormat(amount: number) {
  return `R${amount.toLocaleString("en-ZA")}`;
}

export const STATUS_LABELS: Record<string, string> = {
  available: "Available",
  occupied: "Occupied",
  cleaning: "Cleaning",
};
