import { useQuery } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";

export type GalleryPhoto = {
  id: string;
  image_url: string;
  caption: string;
  sort_order: number;
  is_visible: boolean;
};

export function useGalleryPhotos(includeHidden = false) {
  return useQuery({
    queryKey: ["gallery-photos", includeHidden],
    queryFn: async (): Promise<GalleryPhoto[]> => {
      let request = supabase
        .from("gallery_photos")
        .select("id, image_url, caption, sort_order, is_visible")
        .order("sort_order")
        .order("created_at");
      if (!includeHidden) request = request.eq("is_visible", true);
      const { data, error } = await request;
      if (error) throw error;
      return (data ?? []) as GalleryPhoto[];
    },
  });
}
