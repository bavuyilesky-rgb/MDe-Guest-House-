import { useQuery } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import { PROPERTY, RATES } from "@/lib/property";

export type SiteSettings = {
  name: string;
  address: string;
  short_address: string;
  phone_display: string;
  whatsapp_number: string;
  email: string;
  maps_query: string;
  about: string;
  rate_overnight: number;
  rate_one_hour: number;
  rate_two_hours: number;
  map_lat: number;
  map_lng: number;
  hero_title: string;
  hero_subtitle: string;
  hero_image_url: string;
  room_image_url: string;
  laundry_image_url: string;
  facebook_url: string | null;
  instagram_url: string | null;
};


export type Contact = {
  id: string;
  label: string;
  person_name: string | null;
  role: string | null;
  phone: string | null;
  whatsapp_number: string | null;
  email: string | null;
  sort_order: number;
  is_active: boolean;
};

export const DEFAULT_SETTINGS: SiteSettings = {
  name: PROPERTY.name,
  address: PROPERTY.address,
  short_address: PROPERTY.shortAddress,
  phone_display: PROPERTY.phoneDisplay,
  whatsapp_number: PROPERTY.whatsappNumber,
  email: PROPERTY.email,
  maps_query: PROPERTY.mapsQuery,
  about:
    "Seven private rooms with en-suite bathrooms and secure parking, a short drive from central Mthatha.",
  rate_overnight: RATES.overnight,
  rate_one_hour: RATES.oneHour,
  rate_two_hours: RATES.twoHours,
  map_lat: 0,
  map_lng: 0,
  hero_title: "Affordable, Private & Secure Accommodation in Mthatha",
  hero_subtitle:
    "Located at the Joe Slovo 4-Way Stop on Mthatha Dam Road. Private en-suite rooms, secure on-site parking, and 24/7 rest stops.",
  hero_image_url: "",
  room_image_url: "",
  laundry_image_url: "",
  facebook_url: "https://facebook.com/mdeguesthouse",
  instagram_url: "https://instagram.com/mdeguesthouse",
};

function socialHref(value: string | null) {
  const v = (value ?? "").trim();
  if (!v) return "";
  return /^https?:\/\//i.test(v) ? v : `https://${v}`;
}

export const siteSettingsQuery = {
  queryKey: ["site-settings"] as const,
  queryFn: async (): Promise<SiteSettings> => {
    const { data, error } = await supabase.from("site_settings").select("*").maybeSingle();
    if (error || !data) return DEFAULT_SETTINGS;
    return {
      ...DEFAULT_SETTINGS,
      ...data,
      rate_overnight: Number(data.rate_overnight),
      rate_one_hour: Number(data.rate_one_hour),
      rate_two_hours: Number(data.rate_two_hours),
      map_lat: Number(data.map_lat ?? 0),
      map_lng: Number(data.map_lng ?? 0),
    };
  },
};

export function useSiteSettings() {
  const query = useQuery(siteSettingsQuery);
  return query.data ?? DEFAULT_SETTINGS;
}

/** Resolves a stored image value (full URL or storage path) to a usable src. */
export function useSiteImage(value: string | null | undefined, fallback: string) {
  const path = (value ?? "").trim();
  const isUrl = /^https?:\/\//i.test(path);
  const signed = useQuery({
    queryKey: ["site-image", path],
    enabled: Boolean(path) && !isUrl,
    staleTime: 1000 * 60 * 30,
    queryFn: async () => {
      const { data, error } = await supabase.storage
        .from("site-images")
        .createSignedUrl(path, 60 * 60 * 24);
      if (error || !data) return null;
      return data.signedUrl;
    },
  });

  if (!path) return fallback;
  if (isUrl) return path;
  return signed.data ?? fallback;
}

export function mapsTarget(settings: SiteSettings) {
  if (settings.map_lat && settings.map_lng) return `${settings.map_lat},${settings.map_lng}`;
  return [settings.name, settings.maps_query].filter(Boolean).join(", ");
}

export function mapEmbedFor(settings: SiteSettings) {
  return `https://www.google.com/maps?q=${encodeURIComponent(mapsTarget(settings))}&z=16&output=embed`;
}

export function directionsFor(settings: SiteSettings) {
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
    mapsTarget(settings),
  )}`;
}


export function useContacts(includeInactive = false) {
  return useQuery({
    queryKey: ["contacts", includeInactive],
    queryFn: async (): Promise<Contact[]> => {
      let request = supabase.from("contacts").select("*").order("sort_order");
      if (!includeInactive) request = request.eq("is_active", true);
      const { data, error } = await request;
      if (error) throw error;
      return (data ?? []) as Contact[];
    },
  });
}

export function telHref(phone: string) {
  return `tel:${phone.replace(/[^\d+]/g, "")}`;
}

export function waHref(number: string, message?: string) {
  const digits = number.replace(/\D/g, "");
  return message
    ? `https://wa.me/${digits}?text=${encodeURIComponent(message)}`
    : `https://wa.me/${digits}`;
}

export { socialHref };
