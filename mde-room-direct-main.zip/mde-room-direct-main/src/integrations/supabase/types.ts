export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.17"
  }
  public: {
    Tables: {
      bookings: {
        Row: {
          check_in: string | null
          check_out: string | null
          created_at: string
          guest_name: string
          guest_phone: string
          id: string
          needs_parking: boolean
          payment_status: string
          room_id: number | null
          stay_type: string
          total_amount: number
        }
        Insert: {
          check_in?: string | null
          check_out?: string | null
          created_at?: string
          guest_name: string
          guest_phone: string
          id?: string
          needs_parking?: boolean
          payment_status?: string
          room_id?: number | null
          stay_type: string
          total_amount?: number
        }
        Update: {
          check_in?: string | null
          check_out?: string | null
          created_at?: string
          guest_name?: string
          guest_phone?: string
          id?: string
          needs_parking?: boolean
          payment_status?: string
          room_id?: number | null
          stay_type?: string
          total_amount?: number
        }
        Relationships: [
          {
            foreignKeyName: "bookings_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      contacts: {
        Row: {
          created_at: string
          email: string | null
          id: string
          is_active: boolean
          label: string
          person_name: string | null
          phone: string | null
          role: string | null
          sort_order: number
          updated_at: string
          whatsapp_number: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean
          label?: string
          person_name?: string | null
          phone?: string | null
          role?: string | null
          sort_order?: number
          updated_at?: string
          whatsapp_number?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean
          label?: string
          person_name?: string | null
          phone?: string | null
          role?: string | null
          sort_order?: number
          updated_at?: string
          whatsapp_number?: string | null
        }
        Relationships: []
      }
      gallery_photos: {
        Row: {
          caption: string
          created_at: string
          id: string
          image_url: string
          is_visible: boolean
          sort_order: number
          updated_at: string
        }
        Insert: {
          caption?: string
          created_at?: string
          id?: string
          image_url?: string
          is_visible?: boolean
          sort_order?: number
          updated_at?: string
        }
        Update: {
          caption?: string
          created_at?: string
          id?: string
          image_url?: string
          is_visible?: boolean
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      laundry_orders: {
        Row: {
          created_at: string
          customer_name: string
          customer_type: string
          id: string
          notes: string | null
          phone_number: string
          service_type: string
          status: string
        }
        Insert: {
          created_at?: string
          customer_name: string
          customer_type?: string
          id?: string
          notes?: string | null
          phone_number: string
          service_type: string
          status?: string
        }
        Update: {
          created_at?: string
          customer_name?: string
          customer_type?: string
          id?: string
          notes?: string | null
          phone_number?: string
          service_type?: string
          status?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          created_at: string
          email: string | null
          id: string
          message: string
          name: string
          phone: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          message: string
          name: string
          phone?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          message?: string
          name?: string
          phone?: string | null
        }
        Relationships: []
      }
      rooms: {
        Row: {
          created_at: string
          has_parking: boolean
          id: number
          is_active: boolean
          room_number: number
          status: string
          title: string
        }
        Insert: {
          created_at?: string
          has_parking?: boolean
          id: number
          is_active?: boolean
          room_number: number
          status?: string
          title: string
        }
        Update: {
          created_at?: string
          has_parking?: boolean
          id?: number
          is_active?: boolean
          room_number?: number
          status?: string
          title?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          about: string
          address: string
          created_at: string
          email: string
          facebook_url: string | null
          hero_image_url: string
          hero_subtitle: string
          hero_title: string
          id: boolean
          instagram_url: string | null
          laundry_image_url: string
          map_lat: number
          map_lng: number
          maps_query: string
          name: string
          phone_display: string
          rate_one_hour: number
          rate_overnight: number
          rate_two_hours: number
          room_image_url: string
          short_address: string
          updated_at: string
          whatsapp_number: string
        }
        Insert: {
          about?: string
          address?: string
          created_at?: string
          email?: string
          facebook_url?: string | null
          hero_image_url?: string
          hero_subtitle?: string
          hero_title?: string
          id?: boolean
          instagram_url?: string | null
          laundry_image_url?: string
          map_lat?: number
          map_lng?: number
          maps_query?: string
          name?: string
          phone_display?: string
          rate_one_hour?: number
          rate_overnight?: number
          rate_two_hours?: number
          room_image_url?: string
          short_address?: string
          updated_at?: string
          whatsapp_number?: string
        }
        Update: {
          about?: string
          address?: string
          created_at?: string
          email?: string
          facebook_url?: string | null
          hero_image_url?: string
          hero_subtitle?: string
          hero_title?: string
          id?: boolean
          instagram_url?: string | null
          laundry_image_url?: string
          map_lat?: number
          map_lng?: number
          maps_query?: string
          name?: string
          phone_display?: string
          rate_one_hour?: number
          rate_overnight?: number
          rate_two_hours?: number
          room_image_url?: string
          short_address?: string
          updated_at?: string
          whatsapp_number?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
