import { useState } from "react";
import { MessageCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PROPERTY, RATES, randsFormat, whatsappLink } from "@/lib/property";

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function formatDate(value: string) {
  if (!value) return "";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString("en-ZA", { day: "numeric", month: "long", year: "numeric" });
}

export function RateCalculator() {
  const [nights, setNights] = useState(1);
  const [checkIn, setCheckIn] = useState(todayIso());
  const [needsParking, setNeedsParking] = useState(true);
  const [hours, setHours] = useState<"1" | "2">("1");
  const [arrival, setArrival] = useState("18:00");

  const overnightTotal = Math.max(1, nights) * RATES.overnight;
  const shortTotal = hours === "1" ? RATES.oneHour : RATES.twoHours;

  const overnightMessage = `Hi ${PROPERTY.name}, I would like to book a room for ${Math.max(
    1,
    nights,
  )} night(s) checking in on ${formatDate(checkIn)}. I will need private parking: ${
    needsParking ? "Yes" : "No"
  }. Total quote: R${overnightTotal}.`;

  const shortMessage = `Hi ${PROPERTY.name}, I would like to book a room for a ${
    hours === "1" ? "1 Hour" : "2 Hours"
  } stay today at ${arrival}.`;

  return (
    <section className="section-shell py-12" id="rates">
      <div className="rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-card)] sm:p-8">
        <h2 className="text-2xl font-bold sm:text-3xl">Work out your rate &amp; book</h2>
        <p className="mt-2 text-muted-foreground">
          Pick your stay, get an instant quote, then confirm it with us on WhatsApp.
        </p>

        <Tabs defaultValue="overnight" className="mt-6">
          <TabsList className="grid w-full grid-cols-2 sm:w-80">
            <TabsTrigger value="overnight">Overnight Stay</TabsTrigger>
            <TabsTrigger value="short">Short Stay</TabsTrigger>
          </TabsList>

          <TabsContent value="overnight" className="mt-6 space-y-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="nights">Number of nights</Label>
                <Input
                  id="nights"
                  type="number"
                  min={1}
                  max={60}
                  value={nights}
                  onChange={(e) => setNights(Number(e.target.value))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="check-in">Check-in date</Label>
                <Input
                  id="check-in"
                  type="date"
                  value={checkIn}
                  onChange={(e) => setCheckIn(e.target.value)}
                />
              </div>
            </div>

            <div className="flex items-center justify-between rounded-lg border border-border bg-secondary px-4 py-3">
              <div>
                <Label htmlFor="parking" className="text-sm font-medium">
                  I need secure private parking
                </Label>
                <p className="text-xs text-muted-foreground">Included at no extra cost.</p>
              </div>
              <Switch id="parking" checked={needsParking} onCheckedChange={setNeedsParking} />
            </div>

            <QuoteRow
              label={`${Math.max(1, nights)} night(s) × ${randsFormat(RATES.overnight)}`}
              total={overnightTotal}
              message={overnightMessage}
            />
          </TabsContent>

          <TabsContent value="short" className="mt-6 space-y-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Stay length</Label>
                <div className="grid grid-cols-2 gap-2">
                  {(["1", "2"] as const).map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setHours(value)}
                      className={`rounded-lg border px-4 py-2.5 text-sm font-medium transition-colors ${
                        hours === value
                          ? "border-primary bg-accent text-accent-foreground"
                          : "border-border bg-card hover:bg-secondary"
                      }`}
                    >
                      {value === "1" ? "1 Hour" : "2 Hours"} ·{" "}
                      {randsFormat(value === "1" ? RATES.oneHour : RATES.twoHours)}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="arrival">Arrival time today</Label>
                <Input
                  id="arrival"
                  type="time"
                  value={arrival}
                  onChange={(e) => setArrival(e.target.value)}
                />
              </div>
            </div>

            <QuoteRow
              label={`${hours === "1" ? "1 Hour" : "2 Hours"} short stay`}
              total={shortTotal}
              message={shortMessage}
            />
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}

function QuoteRow({
  label,
  total,
  message,
}: {
  label: string;
  total: number;
  message: string;
}) {
  return (
    <div className="flex flex-col gap-4 rounded-xl border border-border bg-secondary p-5 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="text-3xl font-bold">{randsFormat(total)}</p>
      </div>
      <Button asChild size="lg" variant="whatsapp">
        <a href={whatsappLink(message)} target="_blank" rel="noreferrer">
          <MessageCircle /> Confirm on WhatsApp
        </a>
      </Button>
    </div>
  );
}
