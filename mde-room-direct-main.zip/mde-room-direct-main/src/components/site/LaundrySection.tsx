import { Clock, MessageCircle, Mail, Shirt, WashingMachine } from "lucide-react";

import { Button } from "@/components/ui/button";
import laundryImage from "@/assets/laundry.jpg";
import { useSiteImage, useSiteSettings, waHref } from "@/lib/site-data";

const services = [
  {
    icon: WashingMachine,
    title: "Wash & Dry",
    text: "Machine wash and tumble dry, sorted and returned neatly packed.",
  },
  {
    icon: Shirt,
    title: "Ironing & Folding",
    text: "Pressed shirts, uniforms and linen, folded and ready to wear.",
  },
  {
    icon: Clock,
    title: "Fast Turnaround Drop-off",
    text: "Drop off in the morning, collect the same day where possible.",
  },
];

export function LaundrySection() {
  const settings = useSiteSettings();
  const laundrySrc = useSiteImage(settings.laundry_image_url, laundryImage);

  return (
    <section className="border-y border-border bg-card py-12" id="laundry">
      <div className="section-shell grid gap-10 lg:grid-cols-2 lg:items-center">
        <div>
          <h2 className="text-2xl font-bold sm:text-3xl">Professional Laundry &amp; Ironing Service</h2>
          <p className="mt-3 text-muted-foreground">
            Open to both in-house guests and surrounding Mthatha &amp; Joe Slovo residents.
          </p>

          <ul className="mt-7 space-y-4">
            {services.map((service) => (
              <li key={service.title} className="flex gap-4 rounded-xl border border-border p-4">
                <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                  <service.icon className="size-5" />
                </span>
                <div>
                  <h3 className="text-base font-semibold">{service.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{service.text}</p>
                </div>
              </li>
            ))}
          </ul>

          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" variant="whatsapp">
              <a
                href={waHref(settings.whatsapp_number, 
                  `Hi ${settings.name}, I would like to ask about your laundry service. Items: `,
                )}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle /> Inquire About Laundry
              </a>
            </Button>
            <Button asChild size="lg" variant="outline">
              <a
                href={`mailto:${settings.email}?subject=${encodeURIComponent("Laundry service inquiry")}`}
              >
                <Mail /> Email us
              </a>
            </Button>
          </div>
        </div>

        <div className="overflow-hidden rounded-2xl border border-border shadow-[var(--shadow-card)]">
          <img
            src={laundrySrc}
            alt="Laundry room with washing machine, dryer, folded linen and ironing board"
            loading="lazy"
            width={1200}
            height={800}
            className="h-full w-full object-cover"
          />
        </div>
      </div>
    </section>
  );
}
