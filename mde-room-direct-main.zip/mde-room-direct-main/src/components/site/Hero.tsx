import { Check, MessageCircle, Phone } from "lucide-react";

import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-guesthouse.jpg";
import { randsFormat } from "@/lib/property";
import { telHref, waHref, useSiteImage, useSiteSettings } from "@/lib/site-data";

export function Hero() {
  const settings = useSiteSettings();
  const heroSrc = useSiteImage(settings.hero_image_url, heroImage);
  const badges = [
    `Overnight: ${randsFormat(settings.rate_overnight)}`,
    `1 Hr: ${randsFormat(settings.rate_one_hour)}`,
    `2 Hrs: ${randsFormat(settings.rate_two_hours)}`,
  ];

  return (
    <section className="border-b border-border bg-card">
      <div className="section-shell grid items-center gap-10 py-12 lg:grid-cols-2 lg:py-16">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-primary">
            Mthatha Dam Road · Joe Slovo
          </p>
          <h1 className="mt-3 text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
            {settings.hero_title}
          </h1>
          <p className="mt-4 text-base text-muted-foreground">
            {settings.hero_subtitle}
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="xl" variant="hero">
              <a
                href={waHref(settings.whatsapp_number, 
                  `Hi ${settings.name}, I would like to check availability for a room.`,
                )}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle /> Book via WhatsApp
              </a>
            </Button>
            <Button asChild size="xl" variant="heroOutline">
              <a href={telHref(settings.phone_display)}>
                <Phone /> Call {settings.phone_display}
              </a>
            </Button>
          </div>

          <ul className="mt-7 flex flex-wrap gap-2">
            {badges.map((badge) => (
              <li
                key={badge}
                className="rounded-full border border-border bg-secondary px-3 py-1.5 text-sm font-medium"
              >
                {badge}
              </li>
            ))}
            <li className="flex items-center gap-1.5 rounded-full border border-primary/30 bg-accent px-3 py-1.5 text-sm font-medium text-accent-foreground">
              <Check className="size-4" /> Secure Private Parking
            </li>
          </ul>
        </div>

        <div className="overflow-hidden rounded-2xl border border-border shadow-[var(--shadow-lifted)]">
          <img
            src={heroSrc}
            alt={`${settings.name} with gated private parking in Mthatha`}
            width={1600}
            height={1072}
            className="h-full w-full object-cover"
          />
        </div>
      </div>
    </section>
  );
}
