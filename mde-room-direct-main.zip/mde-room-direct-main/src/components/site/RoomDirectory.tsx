import { useQuery } from "@tanstack/react-query";
import { MessageCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import roomImage from "@/assets/room-interior.jpg";
import { supabase } from "@/integrations/supabase/client";
import { ROOM_AMENITIES, randsFormat } from "@/lib/property";
import { useSiteImage, useSiteSettings, waHref } from "@/lib/site-data";

type Room = {
  id: number;
  room_number: number;
  title: string;
  status: string;
  has_parking: boolean;
};

const fallbackRooms: Room[] = Array.from({ length: 7 }, (_, i) => ({
  id: i + 1,
  room_number: i + 1,
  title: `Room ${i + 1}`,
  status: "available",
  has_parking: true,
}));

function statusClasses(status: string) {
  if (status === "occupied") return "border-destructive/30 bg-destructive/10 text-destructive";
  if (status === "cleaning") return "border-warning/40 bg-warning/15 text-foreground";
  return "border-success/30 bg-success/10 text-success";
}

function statusLabel(status: string) {
  if (status === "occupied") return "Occupied";
  if (status === "cleaning") return "Cleaning";
  return "Available";
}

export function RoomDirectory() {
  const settings = useSiteSettings();
  const roomSrc = useSiteImage(settings.room_image_url, roomImage);
  const { data, isLoading } = useQuery({
    queryKey: ["rooms"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("rooms")
        .select("id, room_number, title, status, has_parking")
        .eq("is_active", true)
        .order("room_number");
      if (error) throw error;
      return data as Room[];
    },
  });

  const rooms = data?.length ? data : fallbackRooms;

  return (
    <section className="section-shell py-12" id="rooms">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold sm:text-3xl">Our 7 rooms</h2>
          <p className="mt-2 max-w-2xl text-muted-foreground">
            Every room is the same: a private double bedroom with its own en-suite bathroom, the
            basics you actually need, and parking included at {randsFormat(settings.rate_overnight)} a night.
          </p>
        </div>
      </div>

      <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {isLoading
          ? Array.from({ length: 3 }).map((_, i) => (
              <li key={i} className="rounded-xl border border-border bg-card p-4">
                <Skeleton className="h-40 w-full rounded-lg" />
                <Skeleton className="mt-4 h-5 w-24" />
                <Skeleton className="mt-2 h-4 w-full" />
              </li>
            ))
          : rooms.map((room) => (
              <li
                key={room.id}
                className="flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-[var(--shadow-card)]"
              >
                <img
                  src={roomSrc}
                  alt={`Interior of ${room.title} at ${settings.name}`}
                  loading="lazy"
                  width={1200}
                  height={912}
                  className="h-44 w-full object-cover"
                />
                <div className="flex flex-1 flex-col p-5">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-lg font-semibold">{room.title}</h3>
                    <span
                      className={`rounded-full border px-2.5 py-1 text-xs font-medium ${statusClasses(room.status)}`}
                    >
                      {statusLabel(room.status)}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Private double room · {randsFormat(settings.rate_overnight)} per night
                  </p>
                  <ul className="mt-4 grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs text-muted-foreground">
                    {ROOM_AMENITIES.map((amenity) => (
                      <li key={amenity} className="flex items-start gap-1.5">
                        <span className="mt-1 size-1.5 shrink-0 rounded-full bg-primary" />
                        {amenity}
                      </li>
                    ))}
                  </ul>
                  <Button asChild variant="whatsapp" className="mt-5 w-full">
                    <a
                      href={waHref(settings.whatsapp_number, 
                        `Hi ${settings.name}, is ${room.title} available? I would like to book it.`,
                      )}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <MessageCircle /> Book {room.title}
                    </a>
                  </Button>
                </div>
              </li>
            ))}
      </ul>
    </section>
  );
}
