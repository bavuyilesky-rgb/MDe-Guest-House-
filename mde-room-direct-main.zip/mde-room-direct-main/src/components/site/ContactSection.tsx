import { useState } from "react";
import { Facebook, Instagram, Mail, MapPin, MessageCircle, Phone, Send } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { PROPERTY } from "@/lib/property";
import { socialHref, telHref, useContacts, useSiteSettings, waHref } from "@/lib/site-data";

export function ContactSection() {
  const settings = useSiteSettings();
  const contacts = useContacts();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!name.trim() || !message.trim()) {
      toast.error("Please add your name and a message.");
      return;
    }
    setSending(true);
    const { error } = await supabase.from("messages").insert({
      name: name.trim(),
      phone: phone.trim() || null,
      email: email.trim() || null,
      message: message.trim(),
    });
    setSending(false);

    if (error) {
      const body = `Name: ${name}\nPhone: ${phone}\nEmail: ${email}\n\n${message}`;
      window.location.href = `${PROPERTY.emailHref}?subject=${encodeURIComponent(
        "Website enquiry",
      )}&body=${encodeURIComponent(body)}`;
      toast.message("Opening your email app instead.");
      return;
    }

    toast.success("Message sent. We'll get back to you shortly.");
    setName("");
    setPhone("");
    setEmail("");
    setMessage("");
  }

  return (
    <section className="section-shell py-12" id="contact">
      <div className="grid gap-8 lg:grid-cols-2">
        <div>
          <h2 className="text-2xl font-bold sm:text-3xl">Contact us</h2>
          <p className="mt-2 text-muted-foreground">
            Call or WhatsApp for the quickest answer on availability. Otherwise leave a message
            below.
          </p>

          <ul className="mt-6 space-y-4 text-sm">
            <li>
              <a
                href={telHref(settings.phone_display)}
                className="flex items-center gap-3 hover:text-primary"
              >
                <span className="inline-flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                  <Phone className="size-5" />
                </span>
                <span>
                  <span className="block font-medium">{settings.phone_display}</span>
                  <span className="text-muted-foreground">Call us directly</span>
                </span>
              </a>
            </li>
            <li>
              <a
                href={waHref(settings.whatsapp_number)}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-3 hover:text-primary"
              >
                <span className="inline-flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                  <MessageCircle className="size-5" />
                </span>
                <span>
                  <span className="block font-medium">{settings.phone_display}</span>
                  <span className="text-muted-foreground">WhatsApp direct line</span>
                </span>
              </a>
            </li>
            <li>
              <a
                href={`mailto:${settings.email}`}
                className="flex items-center gap-3 hover:text-primary"
              >
                <span className="inline-flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                  <Mail className="size-5" />
                </span>
                <span>
                  <span className="block break-all font-medium">{settings.email}</span>
                  <span className="text-muted-foreground">Email enquiries</span>
                </span>
              </a>
            </li>
            <li className="flex items-center gap-3">
              <span className="inline-flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                <MapPin className="size-5" />
              </span>
              <span className="text-muted-foreground">{settings.address}</span>
            </li>
            {(socialHref(settings.facebook_url) || socialHref(settings.instagram_url)) && (
              <li className="flex items-center gap-3">
                <span className="inline-flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                  <Send className="size-5" />
                </span>
                <span className="flex flex-wrap items-center gap-x-4 gap-y-1">
                  {socialHref(settings.facebook_url) && (
                    <a
                      href={socialHref(settings.facebook_url)}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 font-medium hover:text-primary"
                    >
                      <Facebook className="size-4" /> @mdeguesthouse
                    </a>
                  )}
                  {socialHref(settings.instagram_url) && (
                    <a
                      href={socialHref(settings.instagram_url)}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 font-medium hover:text-primary"
                    >
                      <Instagram className="size-4" /> @mdeguesthouse
                    </a>
                  )}
                </span>
              </li>
            )}
          </ul>

          {contacts.data && contacts.data.length > 0 ? (
            <div className="mt-8">
              <h3 className="text-sm font-semibold">Who to contact</h3>
              <ul className="mt-3 space-y-3 text-sm">
                {contacts.data.map((contact) => (
                  <li key={contact.id} className="rounded-xl border border-border bg-card p-4">
                    <p className="font-medium">
                      {contact.label}
                      {contact.person_name ? ` — ${contact.person_name}` : ""}
                    </p>
                    {contact.role ? (
                      <p className="text-muted-foreground">{contact.role}</p>
                    ) : null}
                    <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1">
                      {contact.phone ? (
                        <a href={telHref(contact.phone)} className="text-primary hover:underline">
                          {contact.phone}
                        </a>
                      ) : null}
                      {contact.whatsapp_number ? (
                        <a
                          href={waHref(contact.whatsapp_number)}
                          target="_blank"
                          rel="noreferrer"
                          className="text-primary hover:underline"
                        >
                          WhatsApp
                        </a>
                      ) : null}
                      {contact.email ? (
                        <a
                          href={`mailto:${contact.email}`}
                          className="break-all text-primary hover:underline"
                        >
                          {contact.email}
                        </a>
                      ) : null}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>

        <form
          onSubmit={handleSubmit}
          className="space-y-4 rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-card)] sm:p-6"
        >
          <h3 className="text-lg font-semibold">Send a quick message</h3>
          <div className="space-y-2">
            <Label htmlFor="c-name">Your name</Label>
            <Input id="c-name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="c-phone">Phone</Label>
              <Input
                id="c-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="c-email">Email</Label>
              <Input
                id="c-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="c-message">Message</Label>
            <Textarea
              id="c-message"
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Dates, number of guests, parking needed…"
              required
            />
          </div>
          <Button type="submit" size="lg" className="w-full" disabled={sending}>
            <Send /> {sending ? "Sending…" : "Send message"}
          </Button>
        </form>
      </div>
    </section>
  );
}
