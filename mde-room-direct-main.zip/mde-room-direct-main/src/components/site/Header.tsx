import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, Phone, MessageCircle, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { PROPERTY, WHATSAPP_PLAIN } from "@/lib/property";

const NAV = [
  { to: "/rooms", label: "Rooms & Rates" },
  { to: "/parking-amenities", label: "Private Parking & Amenities" },
  { to: "/gallery", label: "Photos" },
  { to: "/laundry", label: "Laundry" },
  { to: "/location", label: "Location" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-card/95 backdrop-blur">
      <div className="section-shell flex h-16 items-center justify-between gap-3">
        <Link to="/" className="flex flex-col leading-tight" onClick={() => setOpen(false)}>
          <span className="text-base font-semibold sm:text-lg">{PROPERTY.name}</span>
          <span className="text-[11px] text-muted-foreground">Mthatha, Eastern Cape</span>
        </Link>

        <nav className="hidden items-center gap-5 lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              activeProps={{ className: "text-sm text-foreground font-medium" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild size="sm" variant="outline" className="hidden sm:inline-flex">
            <a href={PROPERTY.phoneHref}>
              <Phone /> Call Us
            </a>
          </Button>
          <Button asChild size="sm" variant="whatsapp">
            <a href={WHATSAPP_PLAIN} target="_blank" rel="noreferrer">
              <MessageCircle /> WhatsApp
            </a>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {open ? (
        <nav className="border-t border-border bg-card lg:hidden">
          <div className="section-shell flex flex-col py-2">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="border-b border-border/60 py-3 text-sm last:border-0"
              >
                {item.label}
              </Link>
            ))}
            <a href={PROPERTY.phoneHref} className="py-3 text-sm font-medium text-primary">
              Call {PROPERTY.phoneDisplay}
            </a>
          </div>
        </nav>
      ) : null}
    </header>
  );
}
