import { useState } from "react";
import { X } from "lucide-react";

import roomImage from "@/assets/room-interior.jpg";
import { useGalleryPhotos, type GalleryPhoto } from "@/lib/gallery-data";
import { useSiteImage } from "@/lib/site-data";

function PhotoTile({ photo, onOpen }: { photo: GalleryPhoto; onOpen: (src: string) => void }) {
  const src = useSiteImage(photo.image_url, roomImage);
  return (
    <li className="overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-card)]">
      <button type="button" onClick={() => onOpen(src)} className="block w-full text-left">
        <img
          src={src}
          alt={photo.caption || "MDe Guest House photo"}
          loading="lazy"
          className="aspect-[4/3] w-full object-cover transition-transform duration-300 hover:scale-[1.03]"
        />
        {photo.caption ? (
          <span className="block px-4 py-3 text-sm text-muted-foreground">{photo.caption}</span>
        ) : null}
      </button>
    </li>
  );
}

export function GallerySection() {
  const photos = useGalleryPhotos();
  const [active, setActive] = useState<string | null>(null);
  const list = photos.data ?? [];

  return (
    <section className="py-12" id="gallery">
      <div className="section-shell">
        <h2 className="text-2xl font-bold sm:text-3xl">Photo Gallery</h2>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          A look at the rooms, the yard and the parking area at MDe Guest House.
        </p>

        {list.length ? (
          <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((photo) => (
              <PhotoTile key={photo.id} photo={photo} onOpen={setActive} />
            ))}
          </ul>
        ) : (
          <div className="mt-8 rounded-xl border border-dashed border-border bg-card p-10 text-center text-sm text-muted-foreground">
            Photos are being added. Call or WhatsApp us and we will send pictures right away.
          </div>
        )}
      </div>

      {active ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/80 p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => setActive(null)}
        >
          <button
            type="button"
            aria-label="Close photo"
            className="absolute right-4 top-4 rounded-full bg-card p-2 text-foreground"
            onClick={() => setActive(null)}
          >
            <X className="size-5" />
          </button>
          <img
            src={active}
            alt="Guest house photo enlarged"
            className="max-h-[85vh] w-auto max-w-full rounded-xl object-contain"
          />
        </div>
      ) : null}
    </section>
  );
}
