import { MessageCircle } from "lucide-react";

import { WHATSAPP_PLAIN } from "@/lib/property";

export function FloatingWhatsApp() {
  return (
    <a
      href={WHATSAPP_PLAIN}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat with MDe Guest House on WhatsApp"
      className="fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-whatsapp px-4 py-3 text-sm font-medium text-whatsapp-foreground shadow-[var(--shadow-lifted)] transition-transform hover:scale-[1.03]"
    >
      <span className="relative flex size-2.5">
        <span className="absolute inline-flex size-2.5 animate-ping rounded-full bg-whatsapp-foreground/70" />
        <span className="relative inline-flex size-2.5 rounded-full bg-whatsapp-foreground" />
      </span>
      <MessageCircle className="size-5" />
      <span className="hidden sm:inline">Chat with us</span>
    </a>
  );
}
