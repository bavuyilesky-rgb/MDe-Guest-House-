import { CarFront, MapPin, Navigation } from "lucide-react";

import { Button } from "@/components/ui/button";
import { directionsFor, mapEmbedFor, useSiteSettings } from "@/lib/site-data";

export function LocationSection() {
  const settings = useSiteSettings();

  return (
    <section className="section-shell py-12" id="location">
      <div className="grid gap-8 lg:grid-cols-2 lg:items-center">
        <div>
          <h2 className="text-2xl font-bold sm:text-3xl">Location, parking &amp; directions</h2>
          <p className="mt-3 flex items-start gap-2 text-muted-foreground">
            <MapPin className="mt-0.5 size-5 shrink-0 text-primary" />
            {settings.address}
          </p>
          <p className="mt-4 flex items-start gap-2 text-muted-foreground">
            <CarFront className="mt-0.5 size-5 shrink-0 text-primary" />
            Easy roadside access at the 4-way stop, with enclosed, safe private parking inside the
            premises. Drive in, park behind the gate, and walk straight to your room.
          </p>
          <Button asChild size="lg" className="mt-6">
            <a href={directionsFor(settings)} target="_blank" rel="noreferrer">
              <Navigation /> Get Directions
            </a>
          </Button>
        </div>

        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-card)]">
          <iframe
            title={`Map showing ${settings.name} in Mthatha`}
            src={mapEmbedFor(settings)}
            loading="lazy"
            className="h-72 w-full border-0 lg:h-80"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}
