import { CarFront, ShowerHead, Refrigerator, Shirt } from "lucide-react";

const items = [
  {
    icon: CarFront,
    title: "Private On-Site Parking",
    text: "Safe, gated space for your car inside the premises.",
  },
  {
    icon: ShowerHead,
    title: "Private En-Suite Bathrooms",
    text: "Full privacy in every room — shower and toilet.",
  },
  {
    icon: Refrigerator,
    title: "In-Room Kitchenette Essentials",
    text: "Bar fridge, microwave and electric kettle in each room.",
  },
  {
    icon: Shirt,
    title: "Laundry Service On-Site",
    text: "Wash, dry and iron available daily.",
  },
];

export function Highlights() {
  return (
    <section className="section-shell py-12">
      <h2 className="text-2xl font-bold sm:text-3xl">Why guests stay with us</h2>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Clean rooms, real privacy, and a locked yard for your vehicle. Practical basics, done
        properly.
      </p>
      <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((item) => (
          <li
            key={item.title}
            className="rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]"
          >
            <span className="inline-flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
              <item.icon className="size-5" />
            </span>
            <h3 className="mt-4 text-base font-semibold">{item.title}</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">{item.text}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
