import { Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone } from "lucide-react";

import { randsFormat } from "@/lib/property";
import { telHref, useSiteSettings } from "@/lib/site-data";

export function Footer() {
  const settings = useSiteSettings();

  return (
    <footer className="mt-16 border-t border-border bg-card">
      <div className="section-shell grid gap-8 py-12 sm:grid-cols-2 lg:grid-cols-3">
        <div>
          <h2 className="text-base font-semibold">{settings.name}</h2>
          <p className="mt-2 text-sm text-muted-foreground">{settings.about}</p>
        </div>

        <div className="space-y-3 text-sm">
          <h3 className="text-sm font-semibold">Contact</h3>
          <a
            href={telHref(settings.phone_display)}
            className="flex items-center gap-2 hover:text-primary"
          >
            <Phone className="size-4 text-primary" /> {settings.phone_display}
          </a>
          <a
            href={`mailto:${settings.email}`}
            className="flex items-center gap-2 break-all hover:text-primary"
          >
            <Mail className="size-4 text-primary" /> {settings.email}
          </a>
          <p className="flex items-start gap-2 text-muted-foreground">
            <MapPin className="mt-0.5 size-4 shrink-0 text-primary" /> {settings.address}
          </p>
        </div>

        <div className="space-y-3 text-sm">
          <h3 className="text-sm font-semibold">Rates</h3>
          <p className="text-muted-foreground">
            Overnight — {randsFormat(settings.rate_overnight)} / night
          </p>
          <p className="text-muted-foreground">1 hour — {randsFormat(settings.rate_one_hour)}</p>
          <p className="text-muted-foreground">2 hours — {randsFormat(settings.rate_two_hours)}</p>
          <div className="flex flex-wrap gap-4 pt-2">
            <Link to="/rooms" className="text-primary hover:underline">
              Rooms
            </Link>
            <Link to="/laundry" className="text-primary hover:underline">
              Laundry
            </Link>
            <Link to="/contact" className="text-primary hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </div>
      <div className="section-shell border-t border-border py-5 text-xs text-muted-foreground">
        © {new Date().getFullYear()} {settings.name}. All rights reserved.
      </div>
    </footer>
  );
}
