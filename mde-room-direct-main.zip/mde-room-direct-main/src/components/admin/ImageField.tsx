import { useRef, useState } from "react";
import { ImageUp, X } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useSiteImage } from "@/lib/site-data";

type Props = {
  label: string;
  hint?: string;
  value: string;
  fallback: string;
  onChange: (value: string) => void;
};

export function ImageField({ label, hint, value, fallback, onChange }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const preview = useSiteImage(value, fallback);

  async function handleFile(file: File) {
    setBusy(true);
    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const path = `${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now()}.${ext}`;
    const { error } = await supabase.storage
      .from("site-images")
      .upload(path, file, { upsert: true, contentType: file.type });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    onChange(path);
    toast.success(`${label} uploaded. Remember to save changes.`);
  }

  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex items-start gap-3">
        <img
          src={preview}
          alt={`${label} preview`}
          className="size-20 shrink-0 rounded-lg border border-border object-cover"
        />
        <div className="space-y-2">
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={busy}
              onClick={() => inputRef.current?.click()}
            >
              <ImageUp /> {busy ? "Uploading…" : "Upload photo"}
            </Button>
            {value ? (
              <Button type="button" variant="ghost" size="sm" onClick={() => onChange("")}>
                <X /> Use default
              </Button>
            ) : null}
          </div>
          <p className="text-xs text-muted-foreground">{hint ?? "JPG or PNG, up to 10MB."}</p>
        </div>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (file) void handleFile(file);
        }}
      />
    </div>
  );
}
