import { useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ImageUp, Trash2 } from "lucide-react";
import { toast } from "sonner";

import roomImage from "@/assets/room-interior.jpg";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useGalleryPhotos, type GalleryPhoto } from "@/lib/gallery-data";
import { useSiteImage } from "@/lib/site-data";

export function GalleryPanel() {
  const queryClient = useQueryClient();
  const photos = useGalleryPhotos(true);
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  function refresh() {
    queryClient.invalidateQueries({ queryKey: ["gallery-photos"] });
  }

  const updatePhoto = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Partial<GalleryPhoto> }) => {
      const { error } = await supabase.from("gallery_photos").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: refresh,
    onError: (error: Error) => toast.error(error.message),
  });

  const removePhoto = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("gallery_photos").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Photo removed.");
      refresh();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  async function handleFiles(files: File[]) {
    setBusy(true);
    let added = 0;
    let order = (photos.data?.length ?? 0) + 1;
    for (const file of files) {
      const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
      const path = `gallery-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const upload = await supabase.storage
        .from("site-images")
        .upload(path, file, { upsert: true, contentType: file.type });
      if (upload.error) {
        toast.error(upload.error.message);
        continue;
      }
      const { error } = await supabase
        .from("gallery_photos")
        .insert({ image_url: path, caption: "", sort_order: order });
      if (error) {
        toast.error(error.message);
        continue;
      }
      order += 1;
      added += 1;
    }
    setBusy(false);
    if (added) {
      toast.success(`${added} photo${added > 1 ? "s" : ""} uploaded.`);
      refresh();
    }
  }

  return (
    <div className="space-y-6">
      <div className="max-w-3xl space-y-3 rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)] sm:p-6">
        <h2 className="text-lg font-semibold">Add photos to the gallery</h2>
        <p className="text-sm text-muted-foreground">
          Upload one or more JPG/PNG photos. They appear on the Photos page straight away.
        </p>
        <Button type="button" disabled={busy} onClick={() => inputRef.current?.click()}>
          <ImageUp /> {busy ? "Uploading…" : "Upload photos"}
        </Button>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(event) => {
            const files = Array.from(event.target.files ?? []);
            event.target.value = "";
            if (files.length) void handleFiles(files);
          }}
        />
      </div>

      {photos.data?.length ? (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {photos.data.map((photo) => (
            <PhotoCard
              key={photo.id}
              photo={photo}
              onCaption={(caption) => updatePhoto.mutate({ id: photo.id, patch: { caption } })}
              onToggle={() =>
                updatePhoto.mutate({ id: photo.id, patch: { is_visible: !photo.is_visible } })
              }
              onRemove={() => removePhoto.mutate(photo.id)}
            />
          ))}
        </ul>
      ) : (
        <div className="rounded-xl border border-dashed border-border bg-card p-10 text-center text-sm text-muted-foreground">
          No photos uploaded yet.
        </div>
      )}
    </div>
  );
}

function PhotoCard({
  photo,
  onCaption,
  onToggle,
  onRemove,
}: {
  photo: GalleryPhoto;
  onCaption: (caption: string) => void;
  onToggle: () => void;
  onRemove: () => void;
}) {
  const src = useSiteImage(photo.image_url, roomImage);
  return (
    <li className="space-y-3 rounded-xl border border-border bg-card p-4 shadow-[var(--shadow-card)]">
      <img
        src={src}
        alt={photo.caption || "Gallery photo"}
        className="aspect-[4/3] w-full rounded-lg border border-border object-cover"
      />
      <div className="space-y-1.5">
        <Label htmlFor={`cap-${photo.id}`} className="text-xs">
          Caption
        </Label>
        <Input
          id={`cap-${photo.id}`}
          defaultValue={photo.caption}
          placeholder="e.g. Room 3 — double bed"
          onBlur={(event) => {
            const value = event.target.value.trim();
            if (value !== photo.caption) onCaption(value);
          }}
        />
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button type="button" variant="outline" size="sm" onClick={onToggle}>
          {photo.is_visible ? "Hide from website" : "Show on website"}
        </Button>
        <Button type="button" variant="outline" size="sm" onClick={onRemove}>
          <Trash2 /> Remove
        </Button>
      </div>
    </li>
  );
}
