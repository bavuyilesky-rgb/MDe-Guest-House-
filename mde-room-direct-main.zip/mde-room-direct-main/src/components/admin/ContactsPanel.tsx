import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useContacts, type Contact } from "@/lib/site-data";

type Draft = {
  label: string;
  person_name: string;
  role: string;
  phone: string;
  whatsapp_number: string;
  email: string;
};

const EMPTY: Draft = {
  label: "",
  person_name: "",
  role: "",
  phone: "",
  whatsapp_number: "",
  email: "",
};

export function ContactsPanel() {
  const queryClient = useQueryClient();
  const contacts = useContacts(true);
  const [draft, setDraft] = useState<Draft>(EMPTY);

  function refresh() {
    queryClient.invalidateQueries({ queryKey: ["contacts"] });
  }

  const addContact = useMutation({
    mutationFn: async (values: Draft) => {
      const { error } = await supabase.from("contacts").insert({
        label: values.label.trim() || "Contact",
        person_name: values.person_name.trim() || null,
        role: values.role.trim() || null,
        phone: values.phone.trim() || null,
        whatsapp_number: values.whatsapp_number.trim() || null,
        email: values.email.trim() || null,
        sort_order: (contacts.data?.length ?? 0) + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Contact added.");
      setDraft(EMPTY);
      refresh();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const updateContact = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Partial<Contact> }) => {
      const { error } = await supabase.from("contacts").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: refresh,
    onError: (error: Error) => toast.error(error.message),
  });

  const removeContact = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("contacts").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Contact removed.");
      refresh();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <div className="space-y-6">
      <form
        onSubmit={(event) => {
          event.preventDefault();
          addContact.mutate(draft);
        }}
        className="max-w-3xl space-y-4 rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)] sm:p-6"
      >
        <h2 className="text-lg font-semibold">Add a contact</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {(
            [
              ["label", "Label (e.g. Reception)"],
              ["person_name", "Person name"],
              ["role", "Role"],
              ["phone", "Phone"],
              ["whatsapp_number", "WhatsApp number"],
              ["email", "Email"],
            ] as [keyof Draft, string][]
          ).map(([key, label]) => (
            <div key={key} className="space-y-2">
              <Label htmlFor={`n-${key}`}>{label}</Label>
              <Input
                id={`n-${key}`}
                value={draft[key]}
                onChange={(event) => setDraft((prev) => ({ ...prev, [key]: event.target.value }))}
              />
            </div>
          ))}
        </div>
        <Button type="submit" disabled={addContact.isPending}>
          <Plus /> Add contact
        </Button>
      </form>

      {contacts.data?.length ? (
        <ul className="space-y-3">
          {contacts.data.map((contact) => (
            <li
              key={contact.id}
              className="rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]"
            >
              <div className="grid gap-3 sm:grid-cols-2">
                {(
                  [
                    ["label", "Label"],
                    ["person_name", "Person name"],
                    ["role", "Role"],
                    ["phone", "Phone"],
                    ["whatsapp_number", "WhatsApp number"],
                    ["email", "Email"],
                  ] as [keyof Contact, string][]
                ).map(([key, label]) => (
                  <div key={key} className="space-y-1.5">
                    <Label htmlFor={`${contact.id}-${key}`} className="text-xs">
                      {label}
                    </Label>
                    <Input
                      id={`${contact.id}-${key}`}
                      defaultValue={(contact[key] as string | null) ?? ""}
                      onBlur={(event) => {
                        const value = event.target.value.trim();
                        if (value === (((contact[key] as string | null) ?? "") as string)) return;
                        updateContact.mutate({
                          id: contact.id,
                          patch: { [key]: value || null } as Partial<Contact>,
                        });
                      }}
                    />
                  </div>
                ))}
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    updateContact.mutate({
                      id: contact.id,
                      patch: { is_active: !contact.is_active },
                    })
                  }
                >
                  {contact.is_active ? "Hide from website" : "Show on website"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => removeContact.mutate(contact.id)}
                >
                  <Trash2 /> Remove
                </Button>
                <span className="text-xs text-muted-foreground">
                  {contact.is_active ? "Visible on website" : "Hidden"}
                </span>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <div className="rounded-xl border border-dashed border-border bg-card p-10 text-center text-sm text-muted-foreground">
          No contacts yet.
        </div>
      )}
    </div>
  );
}
