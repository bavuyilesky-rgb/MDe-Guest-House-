import { useEffect, useState } from "react";
import { KeyRound } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export function PasswordPanel() {
  const [email, setEmail] = useState("");
  const [currentEmail, setCurrentEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setCurrentEmail(data.user?.email ?? "");
      setEmail(data.user?.email ?? "");
    });
  }, []);

  async function savePassword(event: React.FormEvent) {
    event.preventDefault();
    if (password.length < 8) {
      toast.error("Use at least 8 characters.");
      return;
    }
    if (password !== confirm) {
      toast.error("The two passwords do not match.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setPassword("");
    setConfirm("");
    toast.success("Password updated. Use it next time you sign in.");
  }

  async function saveEmail(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ email });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Login email updated.");
  }

  return (
    <div className="max-w-xl space-y-6">
      <form
        onSubmit={savePassword}
        className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)] sm:p-6"
      >
        <div>
          <h2 className="text-lg font-semibold">Change staff password</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Signed in as {currentEmail || "…"}. The new password applies immediately.
          </p>
        </div>
        <div className="space-y-2">
          <Label htmlFor="new-password">New password</Label>
          <Input
            id="new-password"
            type="password"
            autoComplete="new-password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirm-password">Confirm new password</Label>
          <Input
            id="confirm-password"
            type="password"
            autoComplete="new-password"
            value={confirm}
            onChange={(event) => setConfirm(event.target.value)}
            required
          />
        </div>
        <Button type="submit" disabled={busy}>
          <KeyRound /> {busy ? "Saving…" : "Update password"}
        </Button>
      </form>

      <form
        onSubmit={saveEmail}
        className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)] sm:p-6"
      >
        <div>
          <h2 className="text-lg font-semibold">Change login email</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            This is the email used to sign in to the admin dashboard.
          </p>
        </div>
        <div className="space-y-2">
          <Label htmlFor="login-email">Login email</Label>
          <Input
            id="login-email"
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            required
          />
        </div>
        <Button type="submit" variant="outline" disabled={busy || email === currentEmail}>
          Update email
        </Button>
      </form>
    </div>
  );
}
