import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Save } from "lucide-react";
import { toast } from "sonner";

import { ImageField } from "@/components/admin/ImageField";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import heroImage from "@/assets/hero-guesthouse.jpg";
import laundryImage from "@/assets/laundry.jpg";
import roomImage from "@/assets/room-interior.jpg";
import { supabase } from "@/integrations/supabase/client";
import { DEFAULT_SETTINGS, siteSettingsQuery, type SiteSettings } from "@/lib/site-data";

const FIELDS: { key: keyof SiteSettings; label: string; type?: string }[] = [
  { key: "name", label: "Guest house name" },
  { key: "phone_display", label: "Phone number" },
  { key: "whatsapp_number", label: "WhatsApp number (e.g. 27783268757)" },
  { key: "email", label: "Email address" },
  { key: "facebook_url", label: "Facebook page URL" },
  { key: "instagram_url", label: "Instagram profile URL" },
  { key: "address", label: "Full address" },
  { key: "short_address", label: "Short address" },
  { key: "maps_query", label: "Google Maps search text" },
  { key: "rate_overnight", label: "Overnight rate (R)", type: "number" },
  { key: "rate_one_hour", label: "1 hour rate (R)", type: "number" },
  { key: "rate_two_hours", label: "2 hours rate (R)", type: "number" },
  { key: "map_lat", label: "Map pin latitude (e.g. -31.5889)", type: "number" },
  { key: "map_lng", label: "Map pin longitude (e.g. 28.7844)", type: "number" },
];


export function SettingsPanel() {
  const queryClient = useQueryClient();
  const { data } = useQuery(siteSettingsQuery);
  const [form, setForm] = useState<SiteSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    if (data) setForm(data);
  }, [data]);

  const save = useMutation({
    mutationFn: async (values: SiteSettings) => {
      const { error } = await supabase
        .from("site_settings")
        .upsert({ id: true, ...values })
        .eq("id", true);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Guest house details updated.");
      queryClient.invalidateQueries({ queryKey: ["site-settings"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        save.mutate(form);
      }}
      className="max-w-3xl space-y-5 rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)] sm:p-6"
    >
      <div>
        <h2 className="text-lg font-semibold">Guest house information</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          These details show on the website, in the rate calculator and on WhatsApp links.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {FIELDS.map((field) => (
          <div key={field.key} className="space-y-2">
            <Label htmlFor={`s-${field.key}`}>{field.label}</Label>
            <Input
              id={`s-${field.key}`}
              type={field.type ?? "text"}
              value={String(form[field.key] ?? "")}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  [field.key]:
                    field.type === "number" ? Number(event.target.value) : event.target.value,
                }))
              }
            />
          </div>
        ))}
      </div>

      <div className="space-y-2">
        <Label htmlFor="s-hero-title">Home page headline</Label>
        <Textarea
          id="s-hero-title"
          rows={2}
          value={form.hero_title}
          onChange={(event) => setForm((prev) => ({ ...prev, hero_title: event.target.value }))}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="s-hero-subtitle">Home page intro under the headline</Label>
        <Textarea
          id="s-hero-subtitle"
          rows={3}
          value={form.hero_subtitle}
          onChange={(event) => setForm((prev) => ({ ...prev, hero_subtitle: event.target.value }))}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="s-about">Footer intro paragraph</Label>
        <Textarea
          id="s-about"
          rows={3}
          value={form.about}
          onChange={(event) => setForm((prev) => ({ ...prev, about: event.target.value }))}
        />
      </div>

      <div className="space-y-5 rounded-xl border border-border p-4">
        <div>
          <h3 className="font-semibold">Website photos</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Upload your own photos. Leave empty to keep the default images.
          </p>
        </div>
        <ImageField
          label="Home page main photo"
          value={form.hero_image_url}
          fallback={heroImage}
          onChange={(value) => setForm((prev) => ({ ...prev, hero_image_url: value }))}
        />
        <ImageField
          label="Room photo"
          value={form.room_image_url}
          fallback={roomImage}
          onChange={(value) => setForm((prev) => ({ ...prev, room_image_url: value }))}
        />
        <ImageField
          label="Laundry photo"
          value={form.laundry_image_url}
          fallback={laundryImage}
          onChange={(value) => setForm((prev) => ({ ...prev, laundry_image_url: value }))}
        />
      </div>


      <Button type="submit" size="lg" disabled={save.isPending}>
        <Save /> {save.isPending ? "Saving…" : "Save changes"}
      </Button>
    </form>
  );
}
