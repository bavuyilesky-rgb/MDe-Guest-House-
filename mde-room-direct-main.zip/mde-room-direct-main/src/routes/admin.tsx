import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BedDouble,
  CalendarClock,
  Contact as ContactIcon,
  Images,
  KeyRound,
  LogOut,
  Settings,
  Shirt,
  MessageSquare,
} from "lucide-react";
import { toast } from "sonner";

import { ContactsPanel } from "@/components/admin/ContactsPanel";
import { GalleryPanel } from "@/components/admin/GalleryPanel";
import { PasswordPanel } from "@/components/admin/PasswordPanel";
import { SettingsPanel } from "@/components/admin/SettingsPanel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { PROPERTY, randsFormat } from "@/lib/property";

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Staff Admin — MDe Guest House" },
      {
        name: "description",
        content:
          "Staff dashboard for MDe Guest House: room status, reservations and laundry orders.",
      },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Staff Admin — MDe Guest House" },
      { property: "og:description", content: "Internal staff dashboard." },
    ],
  }),
  component: AdminPage,
});

type Room = {
  id: number;
  room_number: number;
  title: string;
  status: string;
  has_parking: boolean;
};

type Booking = {
  id: string;
  room_id: number | null;
  guest_name: string;
  guest_phone: string;
  stay_type: string;
  needs_parking: boolean;
  check_in: string | null;
  total_amount: number;
  payment_status: string;
  created_at: string;
};

type LaundryOrder = {
  id: string;
  customer_name: string;
  phone_number: string;
  customer_type: string;
  service_type: string;
  notes: string | null;
  status: string;
  created_at: string;
};

type Message = {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  message: string;
  created_at: string;
};

const STAY_LABELS: Record<string, string> = {
  overnight: "Overnight",
  "1_hour": "1 hour",
  "2_hours": "2 hours",
};

const LAUNDRY_STATUSES = ["received", "in_progress", "ready", "collected"] as const;
const LAUNDRY_LABELS: Record<string, string> = {
  received: "Received",
  in_progress: "In progress",
  ready: "Ready",
  collected: "Collected",
};

function AdminPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSignedIn(Boolean(data.session)));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setSignedIn(Boolean(session));
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  async function handleSignIn(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setPassword("");
    queryClient.invalidateQueries();
  }

  if (signedIn === null) {
    return (
      <main className="section-shell py-16">
        <p className="text-sm text-muted-foreground">Loading…</p>
      </main>
    );
  }

  if (!signedIn) {
    return (
      <main className="section-shell flex justify-center py-16">
        <form
          onSubmit={handleSignIn}
          className="w-full max-w-sm space-y-4 rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)]"
        >
          <div>
            <h1 className="text-xl font-semibold">Staff sign in</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {PROPERTY.name} admin dashboard. Staff accounts only.
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="admin-email">Email</Label>
            <Input
              id="admin-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="admin-password">Password</Label>
            <Input
              id="admin-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full" size="lg" disabled={busy}>
            {busy ? "Signing in…" : "Sign in"}
          </Button>
        </form>
      </main>
    );
  }

  return <AdminDashboard />;
}

function AdminDashboard() {
  const queryClient = useQueryClient();

  const rooms = useQuery({
    queryKey: ["admin-rooms"],
    queryFn: async () => {
      const { data, error } = await supabase.from("rooms").select("*").order("room_number");
      if (error) throw error;
      return data as Room[];
    },
  });

  const bookings = useQuery({
    queryKey: ["admin-bookings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Booking[];
    },
  });

  const laundry = useQuery({
    queryKey: ["admin-laundry"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("laundry_orders")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as LaundryOrder[];
    },
  });

  const messages = useQuery({
    queryKey: ["admin-messages"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Message[];
    },
  });

  const setRoomStatus = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const { error } = await supabase.from("rooms").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-rooms"] });
      queryClient.invalidateQueries({ queryKey: ["rooms"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const setLaundryStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("laundry_orders").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-laundry"] }),
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <main className="section-shell py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold sm:text-3xl">Admin dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Room status, reservations and laundry orders.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={async () => {
            await supabase.auth.signOut();
            queryClient.clear();
          }}
        >
          <LogOut /> Sign out
        </Button>
      </div>

      <Tabs defaultValue="rooms" className="mt-8">
        <TabsList className="flex w-full flex-wrap justify-start">
          <TabsTrigger value="rooms">
            <BedDouble className="mr-1.5 size-4" /> Rooms
          </TabsTrigger>
          <TabsTrigger value="bookings">
            <CalendarClock className="mr-1.5 size-4" /> Reservations
          </TabsTrigger>
          <TabsTrigger value="laundry">
            <Shirt className="mr-1.5 size-4" /> Laundry
          </TabsTrigger>
          <TabsTrigger value="messages">
            <MessageSquare className="mr-1.5 size-4" /> Messages
          </TabsTrigger>
          <TabsTrigger value="contacts">
            <ContactIcon className="mr-1.5 size-4" /> Contacts
          </TabsTrigger>
          <TabsTrigger value="photos">
            <Images className="mr-1.5 size-4" /> Photos
          </TabsTrigger>
          <TabsTrigger value="info">
            <Settings className="mr-1.5 size-4" /> Website content
          </TabsTrigger>
          <TabsTrigger value="security">
            <KeyRound className="mr-1.5 size-4" /> Login &amp; password
          </TabsTrigger>
        </TabsList>

        <TabsContent value="rooms" className="mt-6">
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {(rooms.data ?? []).map((room) => (
              <li
                key={room.id}
                className="rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold">{room.title}</h2>
                  <span className="text-xs text-muted-foreground">
                    {room.has_parking ? "Parking included" : "No parking"}
                  </span>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2">
                  {(["available", "occupied", "cleaning"] as const).map((status) => (
                    <button
                      key={status}
                      type="button"
                      onClick={() => setRoomStatus.mutate({ id: room.id, status })}
                      className={`rounded-lg border px-2 py-2 text-xs font-medium capitalize transition-colors ${
                        room.status === status
                          ? "border-primary bg-accent text-accent-foreground"
                          : "border-border bg-card hover:bg-secondary"
                      }`}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </li>
            ))}
          </ul>
        </TabsContent>

        <TabsContent value="bookings" className="mt-6">
          {bookings.data?.length ? (
            <div className="overflow-x-auto rounded-xl border border-border bg-card">
              <table className="w-full text-sm">
                <thead className="bg-secondary text-left">
                  <tr>
                    <th className="px-4 py-3">Guest</th>
                    <th className="px-4 py-3">Room</th>
                    <th className="px-4 py-3">Stay</th>
                    <th className="px-4 py-3">Check-in</th>
                    <th className="px-4 py-3">Parking</th>
                    <th className="px-4 py-3">Total</th>
                    <th className="px-4 py-3">Payment</th>
                  </tr>
                </thead>
                <tbody>
                  {bookings.data.map((booking) => (
                    <tr key={booking.id} className="border-t border-border">
                      <td className="px-4 py-3">
                        <span className="block font-medium">{booking.guest_name}</span>
                        <span className="text-muted-foreground">{booking.guest_phone}</span>
                      </td>
                      <td className="px-4 py-3">{booking.room_id ? `Room ${booking.room_id}` : "—"}</td>
                      <td className="px-4 py-3">{STAY_LABELS[booking.stay_type] ?? booking.stay_type}</td>
                      <td className="px-4 py-3">
                        {booking.check_in ? new Date(booking.check_in).toLocaleString("en-ZA") : "—"}
                      </td>
                      <td className="px-4 py-3">{booking.needs_parking ? "Yes" : "No"}</td>
                      <td className="px-4 py-3">{randsFormat(Number(booking.total_amount))}</td>
                      <td className="px-4 py-3 capitalize">{booking.payment_status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState text="No reservations recorded yet." />
          )}
        </TabsContent>

        <TabsContent value="laundry" className="mt-6">
          {laundry.data?.length ? (
            <ul className="space-y-3">
              {laundry.data.map((order) => (
                <li
                  key={order.id}
                  className="rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="font-semibold">{order.customer_name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {order.phone_number} ·{" "}
                        {order.customer_type === "guest" ? "In-house guest" : "Local resident"} ·{" "}
                        {order.service_type}
                      </p>
                      {order.notes ? <p className="mt-2 text-sm">{order.notes}</p> : null}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {LAUNDRY_STATUSES.map((status) => (
                        <button
                          key={status}
                          type="button"
                          onClick={() => setLaundryStatus.mutate({ id: order.id, status })}
                          className={`rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                            order.status === status
                              ? "border-primary bg-accent text-accent-foreground"
                              : "border-border bg-card hover:bg-secondary"
                          }`}
                        >
                          {LAUNDRY_LABELS[status]}
                        </button>
                      ))}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState text="No laundry orders logged yet." />
          )}
        </TabsContent>

        <TabsContent value="messages" className="mt-6">
          {messages.data?.length ? (
            <ul className="space-y-3">
              {messages.data.map((message) => (
                <li
                  key={message.id}
                  className="rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="font-semibold">{message.name}</h3>
                    <span className="text-xs text-muted-foreground">
                      {new Date(message.created_at).toLocaleString("en-ZA")}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {[message.phone, message.email].filter(Boolean).join(" · ") || "No contact given"}
                  </p>
                  <p className="mt-3 text-sm">{message.message}</p>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState text="No messages yet." />
          )}
        </TabsContent>

        <TabsContent value="contacts" className="mt-6">
          <ContactsPanel />
        </TabsContent>

        <TabsContent value="photos" className="mt-6">
          <GalleryPanel />
        </TabsContent>

        <TabsContent value="info" className="mt-6">
          <SettingsPanel />
        </TabsContent>

        <TabsContent value="security" className="mt-6">
          <PasswordPanel />
        </TabsContent>
      </Tabs>
    </main>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="rounded-xl border border-dashed border-border bg-card p-10 text-center text-sm text-muted-foreground">
      {text}
    </div>
  );
}
