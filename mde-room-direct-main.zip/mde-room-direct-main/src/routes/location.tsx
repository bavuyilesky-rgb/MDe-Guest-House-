import { createFileRoute } from "@tanstack/react-router";

import { LocationSection } from "@/components/site/LocationSection";

const title = "Location & Directions — MDe Guest House, Mthatha";
const description =
  "Find MDe Guest House at the Joe Slovo 4-way stop on Mthatha Dam Road, Mthatha. Easy roadside access with enclosed, safe private parking on the premises.";

export const Route = createFileRoute("/location")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: LocationPage,
});

function LocationPage() {
  return (
    <main>
      <section className="border-b border-border bg-card py-12">
        <div className="section-shell">
          <h1 className="text-3xl font-bold sm:text-4xl">How to find us</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            We are right at the Joe Slovo 4-way stop on Mthatha Dam Road — easy to reach day or
            night.
          </p>
        </div>
      </section>
      <LocationSection />
    </main>
  );
}
