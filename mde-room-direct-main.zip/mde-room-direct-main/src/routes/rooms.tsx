import { createFileRoute } from "@tanstack/react-router";

import { RateCalculator } from "@/components/site/RateCalculator";
import { RoomDirectory } from "@/components/site/RoomDirectory";
import { RATES, randsFormat } from "@/lib/property";

const title = "Rooms & Rates — MDe Guest House, Mthatha";
const description =
  "Seven identical private en-suite rooms in Mthatha. Overnight R400 per night, 1 hour R100, 2 hours R150, with secure private parking included.";

export const Route = createFileRoute("/rooms")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: RoomsPage,
});

function RoomsPage() {
  return (
    <main>
      <section className="border-b border-border bg-card py-12">
        <div className="section-shell">
          <h1 className="text-3xl font-bold sm:text-4xl">Rooms &amp; rates</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            All seven rooms are identical: a private double bedroom with its own en-suite shower and
            toilet, TV, bar fridge, microwave, kettle, fan, wardrobe, table and chairs, and an iron
            with ironing board. Secure parking is included with every stay.
          </p>
          <ul className="mt-6 flex flex-wrap gap-2 text-sm font-medium">
            <li className="rounded-full border border-border bg-secondary px-3 py-1.5">
              Overnight: {randsFormat(RATES.overnight)} / night
            </li>
            <li className="rounded-full border border-border bg-secondary px-3 py-1.5">
              1 Hour: {randsFormat(RATES.oneHour)}
            </li>
            <li className="rounded-full border border-border bg-secondary px-3 py-1.5">
              2 Hours: {randsFormat(RATES.twoHours)}
            </li>
          </ul>
        </div>
      </section>
      <RoomDirectory />
      <RateCalculator />
    </main>
  );
}
