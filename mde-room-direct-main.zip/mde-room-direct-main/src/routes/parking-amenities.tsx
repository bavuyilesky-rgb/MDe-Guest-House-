import { createFileRoute } from "@tanstack/react-router";

import { Highlights } from "@/components/site/Highlights";
import { LocationSection } from "@/components/site/LocationSection";
import { ROOM_AMENITIES } from "@/lib/property";

const title = "Private Parking & Amenities — MDe Guest House";
const description =
  "Secure gated on-site parking, private en-suite bathrooms, in-room fridge, microwave and kettle, plus daily laundry at MDe Guest House in Mthatha.";

export const Route = createFileRoute("/parking-amenities")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: AmenitiesPage,
});

function AmenitiesPage() {
  return (
    <main>
      <section className="border-b border-border bg-card py-12">
        <div className="section-shell">
          <h1 className="text-3xl font-bold sm:text-4xl">Private parking &amp; amenities</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            Guests with vehicles park inside the premises behind a closed gate — no street parking.
            Every room is self-contained, so you never share a bathroom or kitchen space.
          </p>
        </div>
      </section>

      <Highlights />

      <section className="section-shell pb-12">
        <h2 className="text-2xl font-bold sm:text-3xl">In every room</h2>
        <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {ROOM_AMENITIES.map((amenity) => (
            <li
              key={amenity}
              className="rounded-lg border border-border bg-card px-4 py-3 text-sm shadow-[var(--shadow-card)]"
            >
              {amenity}
            </li>
          ))}
        </ul>
      </section>

      <LocationSection />
    </main>
  );
}
