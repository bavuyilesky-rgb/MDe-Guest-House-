import { createFileRoute } from "@tanstack/react-router";

import { Hero } from "@/components/site/Hero";
import { Highlights } from "@/components/site/Highlights";
import { RateCalculator } from "@/components/site/RateCalculator";
import { RoomDirectory } from "@/components/site/RoomDirectory";
import { GallerySection } from "@/components/site/GallerySection";
import { LaundrySection } from "@/components/site/LaundrySection";
import { LocationSection } from "@/components/site/LocationSection";
import { ContactSection } from "@/components/site/ContactSection";

const title = "MDe Guest House — Private Rooms & Secure Parking, Mthatha";
const description =
  "Private en-suite rooms in Joe Slovo, Mthatha Dam Road. Overnight R400, 1 hour R100, 2 hours R150. Secure on-site parking and on-site laundry.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main>
      <Hero />
      <Highlights />
      <RateCalculator />
      <RoomDirectory />
      <GallerySection />
      <LaundrySection />
      <LocationSection />
      <ContactSection />
    </main>
  );
}
