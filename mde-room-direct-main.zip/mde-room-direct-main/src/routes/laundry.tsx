import { createFileRoute } from "@tanstack/react-router";

import { LaundrySection } from "@/components/site/LaundrySection";

const title = "Laundry & Ironing Service — MDe Guest House, Mthatha";
const description =
  "Wash, dry, iron and fold laundry service at MDe Guest House in Joe Slovo, Mthatha. Open to guests and surrounding residents, with fast drop-off turnaround.";

export const Route = createFileRoute("/laundry")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: LaundryPage,
});

function LaundryPage() {
  return (
    <main>
      <section className="border-b border-border bg-card py-12">
        <div className="section-shell">
          <h1 className="text-3xl font-bold sm:text-4xl">Laundry &amp; ironing</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            Drop your washing off at reception. We wash, dry, iron and fold — for guests staying with
            us and for households and workers around Joe Slovo and Mthatha.
          </p>
        </div>
      </section>
      <LaundrySection />
    </main>
  );
}
