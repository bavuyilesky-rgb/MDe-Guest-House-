import { createFileRoute } from "@tanstack/react-router";

import { GallerySection } from "@/components/site/GallerySection";

const title = "Photos — MDe Guest House, Mthatha";
const description =
  "Browse photos of MDe Guest House in Joe Slovo, Mthatha: private en-suite rooms, secure parking and the on-site laundry.";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  return (
    <main>
      <GallerySection />
    </main>
  );
}
