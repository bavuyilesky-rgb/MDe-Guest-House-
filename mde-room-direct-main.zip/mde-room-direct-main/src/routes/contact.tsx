import { createFileRoute } from "@tanstack/react-router";

import { ContactSection } from "@/components/site/ContactSection";

const title = "Contact MDe Guest House — Call or WhatsApp 078 326 8757";
const description =
  "Contact MDe Guest House in Mthatha: call 078 326 8757, WhatsApp +27 78 326 8757, or email mdguesthouse8@gmail.com for bookings and laundry.";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <main>
      <section className="border-b border-border bg-card py-12">
        <div className="section-shell">
          <h1 className="text-3xl font-bold sm:text-4xl">Get in touch</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            Bookings, laundry drop-offs or directions — we answer WhatsApp fastest.
          </p>
        </div>
      </section>
      <ContactSection />
    </main>
  );
}
